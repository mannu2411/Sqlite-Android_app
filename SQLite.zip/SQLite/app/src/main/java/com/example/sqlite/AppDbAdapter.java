package com.example.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.lang.reflect.Constructor;

public class AppDbAdapter extends SQLiteOpenHelper {

    public AppDbAdapter(Context context) {
        super(context, "appdb", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table person(name text,mobile text,password text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void saveData(String name,String mobile,String password)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name",name);
        cv.put("mobile",mobile);
        cv.put("password",password);
        db.insert("person",null,cv);
    }
    public Cursor getData()
    {
        Cursor c=null;
        SQLiteDatabase db =this.getReadableDatabase();
        c=db.rawQuery("select * from person",null);
        if(c!=null)
        {
            c.moveToFirst();
        }
        return c;
    }
    public void deleteData(String mobile)
    {
        SQLiteDatabase db =this.getWritableDatabase();
        db.delete("person","mobile"+" = "+mobile,null);
    }
    public void updateData(String mobile,String name)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("name",name);
        db.update("person",cv,"mobile"+" = "+mobile,null);
    }
}
