package com.example.sqlite;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText nameEditText,mobileEditText,passwordEditText;
    Button submitButton,showButton,updateButton,deleteButton;
    TextView display;
    AppDbAdapter dbAdapter=new AppDbAdapter(MainActivity.this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameEditText=findViewById(R.id.name);
        mobileEditText=findViewById(R.id.phone);
        passwordEditText=findViewById(R.id.pass);
        submitButton=findViewById(R.id.save);
        showButton=findViewById(R.id.show);
        deleteButton=findViewById(R.id.delete);
        updateButton=findViewById(R.id.Update);
        display=findViewById(R.id.display);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name =nameEditText.getText().toString();
                String mobile=mobileEditText.getText().toString();
                String password=passwordEditText.getText().toString();
                dbAdapter.saveData(name,mobile,password);
                display.setText("Saved");

            }
        });
        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor =dbAdapter.getData();
                String Data="";
                do{
                    String name=cursor.getString(cursor.getColumnIndex("name"));
                    String mobile=cursor.getString(cursor.getColumnIndex("mobile"));
                    String password=cursor.getString(cursor.getColumnIndex("password"));
                    Data=Data+name+" "+mobile+" "+password+"\n";
                }while(cursor.moveToNext());
                display.setText(Data);
            }
        });
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mobile=mobileEditText.getText().toString();
                String name=nameEditText.getText().toString();
                dbAdapter.updateData(mobile,name);
              }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mobile=mobileEditText.getText().toString();
                String name=nameEditText.getText().toString();
                dbAdapter.deleteData(mobile);
            }
        });
    }
}
